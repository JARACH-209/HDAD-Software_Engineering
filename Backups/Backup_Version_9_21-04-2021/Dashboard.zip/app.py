from hdad import app
from hdad import db

if __name__ == '__main__':
    app.run()
