from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, IntegerField , SubmitField, RadioField, SelectField , DecimalField 
from flask_wtf.file import FileField, FileRequired
from wtforms.validators import InputRequired, Email, Length
from wtforms.fields.html5 import EmailField
from wtforms.widgets import TextArea

class LoginForm(FlaskForm):
    username = StringField('username', validators=[
                           InputRequired(), Length(min=1, max=15)])
    password = PasswordField('password', validators=[
                             InputRequired(), Length(min=1, max=80)])
    remember = BooleanField('remember me')

class UploadCSV(FlaskForm):
    csv = FileField(validators=[FileRequired()])

class UsernameForm(FlaskForm):

    Email = EmailField('Email', validators=[
                          InputRequired(), Length(max=100)])


class RegisterForm(FlaskForm):
    DocName = StringField('Name', validators=[
                          InputRequired(), Length(max=100)])
    DocHospital = StringField('Hospital', validators=[
                              InputRequired(), Length(max=100)])
    Email = EmailField('Email', validators=[
                          InputRequired(), Length(max=100)])
    password = PasswordField('password', validators=[
                             InputRequired(), Length(min=8, max=80)])


class PatientForm(FlaskForm):
    PatientName = StringField('Patient Name', validators=[
        InputRequired(), Length(min=1,max=100)])

class ConfirmDelete(FlaskForm):
    Input = StringField('Delete', validators=[
        InputRequired(), Length(min=1,max=100)])
class TokenForm(FlaskForm):
    Token = StringField('Security Key', validators=[
        InputRequired(), Length(max=10)])
class NewPassword(FlaskForm):
    password = PasswordField('password', validators=[
                             InputRequired(), Length(min=8, max=80)])
    Confirmpassword = PasswordField('password', validators=[
                             InputRequired(), Length(min=8, max=80)])
class MailForm(FlaskForm):
    email = StringField('Patient Email', validators=[
        InputRequired(), Email(message='Invalid email'),Length(max=100)])
    message = StringField('message', widget=TextArea())
    
class StatsSelector(FlaskForm):
    Feature1 = SelectField('Label1', choices=[('BNP','Brain Natriuretic Peptide'),('Cholestrol','Cholestrol'),('CEM','Creatnine Enzymetic Method'),('CreatnineKinase','Creatnine Kinase'),('Cystatin','Cystatin'),('Killip','Killip Grade'),('LVEDD','left ventricular end diastolic diameter LV'),('NYHA','NYHA Cardiac Function Classification'),('Potassium','Potassium'),('Pulse','Pulse'),('SystolicBP','Systolic Blood Presure')])
    Feature2 = SelectField('Label2', choices=[('Date','Date'),('BNP','Brain Natriuretic Peptide'),('Cholestrol','Cholestrol'),('CEM','Creatnine Enzymetic Method'),('CreatnineKinase','Creatnine Kinase'),('Cystatin','Cystatin'),('Killip','Killip Grade'),('LVEDD','left ventricular end diastolic diameter LV'),('NYHA','NYHA Cardiac Function Classification'),('Potassium','Potassium'),('Pulse','Pulse'),('SystolicBP','Systolic Blood Presure')])



class CHFDiagnostics(FlaskForm):
    Pulse = DecimalField('Pulse', validators=[
        InputRequired()] )
    NYHA = SelectField('NYHA', choices=[('1','NYHA Cardiac Function Classification'),('1','1'),('2','2'),('3','3'),('4','4')],validators=[InputRequired()])
    Killip = SelectField('KillipGrade', choices=[('1','Killip Grade'),('1','1'),('2','2'),('3','3'),('4','4')],validators=[InputRequired()])
    BNP = DecimalField('Brain Natriuretic Peptide', validators=[
        InputRequired()])
    Cystatin = DecimalField('Cystatin', validators=[
        InputRequired()])
    Potassium = DecimalField('Potassium', validators=[
        InputRequired()])
    CHFsubmit = SubmitField('Submit')



class HFDiagnostics(FlaskForm):
    Pulse2 = DecimalField('Pulse', validators=[
        InputRequired() ])
    SystolicBP = DecimalField('Systolic Blood Presure', validators=[
        InputRequired() ])
    LVEDD = DecimalField('left ventricular end diastolic diameter LV', validators=[
        InputRequired()])
    BNP2 = DecimalField('Brain Natriuretic Peptide', validators=[
        InputRequired()])
    CreatnineKinase = DecimalField('Creatnine Kinase', validators=[
        InputRequired()])
    Cholestrol = DecimalField('Cholestrol', validators=[
        InputRequired()])
    CEM = DecimalField('Creatinine Enzymetic Method', validators=[
        InputRequired()])
    Potassium2 = DecimalField('Potassium', validators=[
        InputRequired()])
    HFsubmit = SubmitField('Submit')

