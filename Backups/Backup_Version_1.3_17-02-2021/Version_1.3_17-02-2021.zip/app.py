from flask import Flask, render_template, redirect, url_for, request
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, IntegerField , SubmitField, RadioField, SelectField , DecimalField
from wtforms.validators import InputRequired, Email, Length
from wtforms.fields.html5 import EmailField
from wtforms.widgets import TextArea
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import os
from flask_mail import Mail, Message
from datetime import datetime
# import sys
# from datetime import datetime
# import model
app = Flask(__name__)
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'ashishmishrajune2000@gmail.com'
app.config['MAIL_PASSWORD'] = 'zgyhqvfcichqxfig'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)
app.config['SECRET_KEY'] = 'SecretKey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
bootstrap = Bootstrap(app)
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    DocName = db.Column(db.String(100))
    DocId = db.Column(db.String(50), unique=True)
    DocHospital = db.Column(db.String(100))
    Email = db.Column(db.String(100))
    password = db.Column(db.String(80))

class Patient(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    PatientName = db.Column(db.String(100))
    PatientId = db.Column(db.String(50), unique=True)
    PatientDocId = db.Column(db.String(50))
    PatientDate = db.Column(db.DateTime, nullable=False,
                            default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class LoginForm(FlaskForm):
    username = StringField('username', validators=[
                           InputRequired(), Length(min=1, max=15)])
    password = PasswordField('password', validators=[
                             InputRequired(), Length(min=1, max=80)])
    remember = BooleanField('remember me')


class RegisterForm(FlaskForm):
    DocName = StringField('Name', validators=[
                          InputRequired(), Length(max=100)])
    DocHospital = StringField('Hospital', validators=[
                              InputRequired(), Length(max=100)])
    Email = EmailField('Email', validators=[
                          InputRequired(), Length(max=100)])
    password = PasswordField('password', validators=[
                             InputRequired(), Length(min=8, max=80)])

class PatientForm(FlaskForm):
    PatientName = StringField('Patient Name', validators=[
        InputRequired(), Length(min=1,max=100)])

@app.route('/')
def index():
        return render_template('index.html')



@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()

    if form.validate_on_submit():
        user = User.query.filter_by(DocId=form.username.data).first()
        if user:
            if check_password_hash(user.password, form.password.data):
                login_user(user, remember=form.remember.data)
                return redirect(url_for('dashboard'))

        return render_template('login.html', form=form,message="Invalid username or password")
        # return '<h1>' + form.username.data + ' ' + form.password.data + '</h1>'
    if current_user.is_authenticated :
        return redirect(url_for('dashboard'))
    else:
        return render_template('login.html', form=form,message="")

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if request.method == 'POST':
        
        if form.validate_on_submit():
            path = os.getcwd()+'/Doctor-Counter.txt'
            f = open(path, 'r')
            DocNum = str(f.read())
            f.close()
            if int(DocNum) < 10:
                ID = 'Doc000' + DocNum
            elif int(DocNum) < 100:
                ID = 'Doc00' + DocNum
            elif int(DocNum) < 1000:
                ID = 'Doc0' + DocNum
            elif int(DocNum) < 10000:
                ID = 'Doc' + DocNum
            try:
                # Email=query_db("select Email from User where Email='"+ form.Email.data +"';")
                user = User.query.filter_by(Email=form.Email.data).first()
                Email = user.Email
                
            except:
                Email=[]
            if Email:
                return render_template('register.html', form=form,message='Accout with the entered Email already exists') 
            try:
                msg = Message( 
                    'HDAD Login Id ', 
                    sender ='ashishmishrajune2000@gmail.com', 
                    recipients = [form.Email.data] 
                ) 
                msg.body = 'Hello '+form.DocName.data+' your account has been created. \nYour Id is '+ID
                mail.send(msg)
            except:
                return render_template('register.html', form=form,message='Try Again')
               
            hashed_password = generate_password_hash(form.password.data, method='sha256')
            new_user = User(DocName=form.DocName.data, DocId=ID,DocHospital=form.DocHospital.data,Email= form.Email.data,password=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            f = open(path, 'w')
            f.write(str(int(DocNum)+1))
            f.close()
                

            return render_template('DocId.html',message="Your Id has been sent to your mail")
            # return '<h1>New user has been created! Your Username is : ' + ID + '</h1>'
        else:
            return render_template('register.html', form=form,message='Password must be minimum 8 and maximum 80 character long')
    else:
        return render_template('register.html', form=form,message='')


@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    form = PatientForm()
    data = Patient.query.filter_by(PatientDocId=current_user.DocId).order_by(Patient.id.desc()).all()
    if request.method == 'POST':

        if form.validate_on_submit():
            path = os.getcwd()+'/Patient-Counter.txt'
            f = open(path, 'r')
            PatientNum = str(f.read())
            f.close()
            if int(PatientNum) < 10:
                ID = 'PA000' + PatientNum
            elif int(PatientNum) < 100:
                ID = 'PA00' + PatientNum
            elif int(PatientNum) < 1000:
                ID = 'PA0' + PatientNum
            elif int(PatientNum) < 10000:
                ID = 'PA' + PatientNum

            new_user = Patient(
                PatientName=form.PatientName.data,
                PatientId=ID, PatientDocId=current_user.DocId)
            db.session.add(new_user)
            db.session.commit()
            f = open(path, 'w')
            f.write(str(int(PatientNum)+1))
            f.close()
            return redirect(url_for('dashboard'))
            # return render_template('PatientId.html', ID=ID, name=current_user.DocName,data=data)
            # return '<h1>New user has been created! Your Username is : ' + ID + '</h1>'
       
    else:
        return render_template('dashboard.html', name=current_user.DocName, form=form,data=data)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
