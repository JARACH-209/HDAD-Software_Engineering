from flask import render_template, redirect, url_for, request
from hdad.forms import LoginForm , UsernameForm , RegisterForm , PatientForm , TokenForm , NewPassword , MailForm , StatsSelector , CHFDiagnostics, CompleteDiagnostics , HFDiagnostics , ConfirmDelete , UploadCSV , Covid
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_mail import  Message
import pickle
import os
import os.path
from os import path
import sys
from flask import send_file, send_from_directory, safe_join, abort
import hdad.create_graphs
import seaborn as sns
import matplotlib.pyplot as plt, mpld3
import numpy as np
from flask import g
from io import TextIOWrapper
import pandas as pd
from hdad.models import User , Patient , PatientDiagnostics , TokenTable , CHF , HF
from hdad import mail , db , app , login_manager


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@app.route('/')
def index():

    if os.path.exists("hdad/Patient-Counter.txt")==False :
        f = open("hdad/Patient-Counter.txt", "w+")
        f.write("0")
        f.close()
    if os.path.exists("hdad/Doctor-Counter.txt")==False :
        f = open("hdad/Doctor-Counter.txt", "w+")
        f.write("0")
        f.close()
    if os.path.exists("hdad/Diagnostics-Counter.txt")==False :
        f = open("hdad/Diagnostics-Counter.txt", "w+")
        f.write("0")
        f.close()
    path = os.getcwd()+'/hdad/Patient-Counter.txt'
    f = open(path, 'r')
    PatientNum = int(f.read())
    path = os.getcwd()+'/hdad/Doctor-Counter.txt'
    f = open(path, 'r')
    DocNum = int(f.read())
    path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
    f = open(path, 'r')
    DiagNum = int(f.read())
    if current_user.is_authenticated :
        return redirect(url_for('dashboard'))
    else:
        return render_template('index.html',patient=PatientNum,doc=DocNum,diag=DiagNum)



@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated :
        return redirect(url_for('dashboard'))
    form = LoginForm()

    if form.validate_on_submit():
        user = User.query.filter_by(DocId=form.username.data).first()
        if user:
            if check_password_hash(user.password, form.password.data):
                login_user(user, remember=form.remember.data)
                return redirect(url_for('dashboard'))

        return render_template('login.html', form=form,message="Invalid username or password")
        # return '<h1>' + form.username.data + ' ' + form.password.data + '</h1>'
    if current_user.is_authenticated :
        return redirect(url_for('dashboard'))
    else:
        return render_template('login.html', form=form,message="")

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated :
        return redirect(url_for('dashboard'))
    form = RegisterForm()
    if request.method == 'POST':
        
        if form.validate_on_submit():
            path = os.getcwd()+'/hdad/Doctor-Counter.txt'
            f = open(path, 'r')
            DocNum = str(f.read())
            f.close()
            if int(DocNum) < 10:
                ID = 'Doc000' + DocNum
            elif int(DocNum) < 100:
                ID = 'Doc00' + DocNum
            elif int(DocNum) < 1000:
                ID = 'Doc0' + DocNum
            elif int(DocNum) < 10000:
                ID = 'Doc' + DocNum
            try:
                # Email=query_db("select Email from User where Email='"+ form.Email.data +"';")
                user = User.query.filter_by(Email=form.Email.data).first()
                Email = user.Email
                
            except:
                Email=[]
            if Email:
                return render_template('register.html', form=form,message='Accout with this Email already exists') 
            try:
                msg = Message( 
                    'HDAD Login Id ', 
                    sender ='ashishmishrajune2000@gmail.com', 
                    recipients = [form.Email.data] 
                ) 
                msg.body = 'Hello '+form.DocName.data+' your account has been created. \nYour Id is '+ID
                mail.send(msg)
            except:
                return render_template('register.html', form=form,message='Try Again')
               
            hashed_password = generate_password_hash(form.password.data, method='sha256')
            new_user = User(DocName=form.DocName.data, DocId=ID,DocHospital=form.DocHospital.data,Email= form.Email.data,password=hashed_password)
            db.session.add(new_user)
            db.session.commit()
            f = open(path, 'w')
            f.write(str(int(DocNum)+1))
            f.close()
                

            return render_template('DocId.html',message="Your Id has been sent to your mail")
            # return '<h1>New user has been created! Your Username is : ' + ID + '</h1>'
        else:
            return render_template('register.html', form=form,message='')
    else:
        return render_template('register.html', form=form,message='')


@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    csvform=UploadCSV()
    form = PatientForm()
    chfform = CHFDiagnostics()
    completeform = CompleteDiagnostics()
    hfform = HFDiagnostics()
    data = Patient.query.filter_by(PatientDocId=current_user.DocId).order_by(Patient.id.desc()).all()
    Diagdata = PatientDiagnostics.query.filter_by(PatientDocId=current_user.DocId).order_by(PatientDiagnostics.id.desc()).all()
    chf = CHF.query.filter_by(PatientDocId=current_user.DocId).order_by(CHF.id.desc()).all()
    hf1 = HF.query.filter_by(PatientDocId=current_user.DocId).order_by(HF.id.desc()).all()
    if request.method == 'POST':

        if form.validate_on_submit():
            path = os.getcwd()+'/hdad/Patient-Counter.txt'
            f = open(path, 'r')
            PatientNum = str(f.read())
            f.close()
            if int(PatientNum) < 10:
                ID = 'PA000' + PatientNum
            elif int(PatientNum) < 100:
                ID = 'PA00' + PatientNum
            elif int(PatientNum) < 1000:
                ID = 'PA0' + PatientNum
            elif int(PatientNum) < 10000:
                ID = 'PA' + PatientNum

            new_user = Patient(
                PatientName=form.PatientName.data,
                PatientId=ID, PatientDocId=current_user.DocId)
            db.session.add(new_user)
            db.session.commit()
            f = open(path, 'w')
            f.write(str(int(PatientNum)+1))
            f.close()
            return redirect(url_for('dashboard'))
            # return render_template('PatientId.html', ID=ID, name=current_user.DocName,data=data)
            # return '<h1>New user has been created! Your Username is : ' + ID + '</h1>'
        elif request.form.get("csvu"):
            print("+")
            print("+")
            print("+")
            print("+")
            print('file')
            try :
                csv_file = request.files['file']
                df = pd.read_csv(csv_file,encoding='latin1')
                df2 = df.copy()
                df = df[df['Name'].notna()]
                df.dropna()
                for x, y  in df.iterrows():
                    print(y['Name'],y['Pulse'])
                    path = os.getcwd()+'/hdad/Patient-Counter.txt'
                    f = open(path, 'r')
                    PatientNum = str(f.read())
                    f.close()
                    if int(PatientNum) < 10:
                        ID = 'PA000' + PatientNum
                    elif int(PatientNum) < 100:
                        ID = 'PA00' + PatientNum
                    elif int(PatientNum) < 1000:
                        ID = 'PA0' + PatientNum
                    elif int(PatientNum) < 10000:
                        ID = 'PA' + PatientNum

                    new_user = Patient(
                        PatientName=y['Name'],
                        PatientId=ID, PatientDocId=current_user.DocId)
                    db.session.add(new_user)
                    db.session.commit()
                    f = open(path, 'w')
                    f.write(str(int(PatientNum)+1))
                    f.close()

                    if y['Pulse'] and y['NYHA Cardiac Function Classification '] and y['Killip-Grade'] and y['Brain Natriuretic Peptide '] and y['Cystatin '] and y['Potassium ']:
                        pulse = y['Pulse']
                        nyha = y['NYHA Cardiac Function Classification ']
                        killip = y['Killip-Grade']
                        bnp = y['Brain Natriuretic Peptide ']
                        cystatin =  y['Cystatin ']
                        potassium = y['Potassium ']

                        
                            
                        Xdata = [ [pulse,nyha,killip,bnp,cystatin,potassium ] ]
                        try:
                            with open('hdad/CHF_Detection_Model.pkl', 'rb') as f:
                                clf = pickle.load(f)
                            x=clf.predict(Xdata)
                            
                            if x == 1:
                                result="yes"
                            elif x == 0:
                                result="no"
                            else:
                                result="error"

                            new_record = PatientDiagnostics(PatientId=ID, PatientDocId=current_user.DocId, DiagnosticsFor=2)
                            db.session.add(new_record)
                            db.session.commit()
                            DiagnosticsId = PatientDiagnostics.query.filter_by(PatientId=ID).order_by(PatientDiagnostics.id.desc()).first()
                            if DiagnosticsId:
                                chf = CHF(DiagnosticsId=DiagnosticsId.id,PatientId=ID,PatientDocId=current_user.DocId, Pulse=pulse, NYHA=nyha, Killip=killip,BNP=bnp,Cystatin=cystatin,Potassium=potassium,Result=result)
                                db.session.add(chf)
                                db.session.commit()
                            path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
                            f = open(path, 'r')
                            DiagnosticsCounter = int(f.read())
                            f.close()
                            f = open(path, 'w')
                            f.write(str(DiagnosticsCounter+1))
                            f.close()
                        except :
                            Xdata = []
                    if y['Pulse'] and y['SystolicBP'] and y['left ventricular end diastolic diameter LV '] and y['Brain Natriuretic Peptide '] and y['Creatnine Enzymetic Method '] and y['Potassium '] and y['Cholesterol'] and y['Creatnine Kinase ']:
                        pulse = y['Pulse']
                        systolicbp = y['SystolicBP']
                        lvedd = y['left ventricular end diastolic diameter LV ']
                        bnp =  y['Brain Natriuretic Peptide ']
                        creatnine=y['Creatnine Kinase ']
                        cholestrol = y['Cholesterol']
                        cem = y['Creatnine Enzymetic Method ']
                        potassium = y['Potassium ']

                        pulse = int(pulse)      
                        systolicbp = int(systolicbp)
                        lvedd = int(lvedd)
                        bnp = int(bnp)
                        creatnine = int(creatnine)
                        cholestrol = int(cholestrol)
                        cem = int(cem)
                        potassium = int(potassium)
                        Xdata = [ [pulse,systolicbp,lvedd,bnp,creatnine,cholestrol,cem,potassium ] ]
                        try :
                            with open('hdad/HF_Classification_Model.pkl', 'rb') as f:
                                clf = pickle.load(f)
                            x=clf.predict(Xdata)
                            
                            if x == 1:
                                result="HFpEF"
                            elif x == 0:
                                result="HFrEF"
                            else:
                                result="error"

                            new_record = PatientDiagnostics(PatientId=ID, PatientDocId=current_user.DocId, DiagnosticsFor=3)
                            db.session.add(new_record)
                            db.session.commit()
                            DiagnosticsId = PatientDiagnostics.query.filter_by(PatientId=ID).order_by(PatientDiagnostics.id.desc()).first()
                            if DiagnosticsId:
                                hf = HF(DiagnosticsId=DiagnosticsId.id,PatientId=ID,PatientDocId=current_user.DocId, Pulse=pulse, SystolicBP=systolicbp,LVEDD=lvedd,BNP=bnp,CreatnineKinase=creatnine,Cholestrol=cholestrol,CEM=cem,Potassium=potassium,Result=result)
                                db.session.add(hf)
                                db.session.commit()
                            path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
                            f = open(path, 'r')
                            DiagnosticsCounter = int(f.read())
                            f.close()
                            f = open(path, 'w')
                            f.write(str(DiagnosticsCounter+1))
                            f.close()
                        except :
                            Xdata=[]
            except :
                return redirect(url_for('dashboard'))

            print("+")
            print("+")
            print("+")
            return redirect(url_for('dashboard'))

        elif request.form.get("download"):
            try:
                return send_from_directory('static', filename='template.csv', as_attachment=True)
            except FileNotFoundError:
                abort(404)

        elif chfform.validate_on_submit() and  request.form.get("submitchf"):
            pulse = chfform.Pulse.data
            nyha = chfform.NYHA.data
            killip = chfform.Killip.data
            bnp = chfform.BNP.data
            cystatin = chfform.Cystatin.data
            potassium = chfform.Potassium.data
            
            try :
                pulse = int(pulse)
                nyha = int(nyha)
                killip = int(killip)
                bnp = int(bnp)
                cystatin = int(cystatin)
                potassium = int(potassium)
            except :
                message="Enter Numerical Values"
                return render_template('dashboard.html', name=current_user.DocName, form=form,data=data,diagdata=Diagdata,chf=chf,hf=hf1,formnum=2,chfform=chfform,completeform=completeform, hfform=hfform,message=message,message2="",csvform=csvform)
            Xdata = [ [pulse,nyha,killip,bnp,cystatin,potassium ] ]
            with open('hdad/CHF_Detection_Model.pkl', 'rb') as f:
                clf = pickle.load(f)
            x=clf.predict(Xdata)

            if x == 1:
               message="Patient Have Congestive Heart Failure"
            elif x == 0:
                message="Patient Does Not Have Congestive Heart Failure"
            else:
                message="error"
            path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
            f = open(path, 'r')
            DiagnosticsCounter = int(f.read())
            f.close()
            f = open(path, 'w')
            f.write(str(DiagnosticsCounter+1))
            f.close()
            return render_template('dashboard.html', name=current_user.DocName, form=form,data=data,completeform=completeform,diagdata=Diagdata,chf=chf,hf=hf1,formnum=2,chfform=chfform, hfform=hfform,message=message,message2="",csvform=csvform)
        elif completeform.validate_on_submit() and  request.form.get("submitcomplete"):
            pulse = completeform.Pulse4.data
            nyha = completeform.NYHA4.data
            killip = completeform.Killip4.data
            bnp = completeform.BNP4.data
            cystatin = completeform.Cystatin4.data
            potassium = completeform.Potassium4.data
            systolicbp = completeform.SystolicBP4.data
            lvedd = completeform.LVEDD4.data
            creatnine=completeform.CreatnineKinase4.data
            cholestrol = completeform.Cholestrol4.data
            cem = completeform.CEM4.data
            try :
                pulse = int(pulse)
                nyha = int(nyha)
                killip = int(killip)
                bnp = int(bnp)
                cystatin = int(cystatin)
                potassium = int(potassium)
                systolicbp = int(systolicbp)
                lvedd = int(lvedd)
                creatnine = int(creatnine)
                cholestrol = int(cholestrol)
                cem = int(cem)
            except :
                message="Enter Numerical Values"
                return render_template('dashboard.html', name=current_user.DocName, form=form,data=data,diagdata=Diagdata,chf=chf,hf=hf1,formnum=2,chfform=chfform,completeform=completeform, hfform=hfform,message=message,message2="",csvform=csvform)
            Xdata = [ [pulse,nyha,killip,bnp,cystatin,potassium ] ]
            with open('hdad/CHF_Detection_Model.pkl', 'rb') as f:
                clf = pickle.load(f)
            x=clf.predict(Xdata)

            if x == 1:
               message="Patient Have Congestive Heart Failure"
            elif x == 0:
                message="Patient Does Not Have Congestive Heart Failure"
            else:
                message="error"
            Xdata = [ [pulse,systolicbp,lvedd,bnp,creatnine,cholestrol,cem,potassium ] ]
            with open('hdad/HF_Classification_Model.pkl', 'rb') as f:
                clf = pickle.load(f)
            x=clf.predict(Xdata)
            
            if x == 1:
               message2="Patient Have HFpEF"
            elif x == 0:
                message2="Patient Have HFrEF"
            else:
                message2="error"
            path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
            f = open(path, 'r')
            DiagnosticsCounter = int(f.read())
            f.close()
            f = open(path, 'w')
            f.write(str(DiagnosticsCounter+2))
            f.close()
            
            return render_template('dashboard.html', name=current_user.DocName, form=form,data=data,completeform=completeform,diagdata=Diagdata,chf=chf,hf=hf1,formnum=4,chfform=chfform, hfform=hfform,message=message,message2=message2,csvform=csvform)
        elif hfform.validate_on_submit() and  request.form.get("submithf"):
            pulse = hfform.Pulse2.data
            systolicbp = hfform.SystolicBP.data
            lvedd = hfform.LVEDD.data
            bnp = hfform.BNP2.data
            creatnine=hfform.CreatnineKinase.data
            cholestrol = hfform.Cholestrol.data
            cem = hfform.CEM.data
            potassium = hfform.Potassium2.data

            pulse = int(pulse)      
            systolicbp = int(systolicbp)
            lvedd = int(lvedd)
            bnp = int(bnp)
            creatnine = int(creatnine)
            cholestrol = int(cholestrol)
            cem = int(cem)
            potassium = int(potassium)
            Xdata = [ [pulse,systolicbp,lvedd,bnp,creatnine,cholestrol,cem,potassium ] ]
            with open('hdad/HF_Classification_Model.pkl', 'rb') as f:
                clf = pickle.load(f)
            x=clf.predict(Xdata)
            
            if x == 1:
               message2="Patient Have HFpEF"
            elif x == 0:
                message2="Patient Have HFrEF"
            else:
                message2="error"
            path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
            f = open(path, 'r')
            DiagnosticsCounter = int(f.read())
            f.close()
            f = open(path, 'w')
            f.write(str(DiagnosticsCounter+1))
            f.close()
            return render_template('dashboard.html', name=current_user.DocName, form=form,completeform=completeform,data=data,diagdata=Diagdata,chf=chf,hf=hf1,formnum=3,chfform=chfform,hfform=hfform,message2=message2,message="",csvform=csvform)
    else:
        return render_template('dashboard.html', name=current_user.DocName, form=form,completeform=completeform,data=data,diagdata=Diagdata,chf=chf,hf=hf1,chfform=chfform,hfform=hfform,fornnum=0,message="",message2="",csvform=csvform)

@app.route('/<pid>',methods=['GET', 'POST'])
@login_required
def showpatient(pid):
    csvform=UploadCSV()
    delete = ConfirmDelete()
    featureform = StatsSelector()
    chfform = CHFDiagnostics()
    completeform=CompleteDiagnostics()
    hfform = HFDiagnostics()
    alert = MailForm()
    Patientdata = Patient.query.filter_by(PatientId=pid).first()
    Diagnostics = PatientDiagnostics.query.filter_by(PatientId=pid).order_by(PatientDiagnostics.id.desc()).first()
    chf = CHF.query.filter_by(PatientId=pid).order_by(CHF.id.desc()).all()
    hf = HF.query.filter_by(PatientId=pid).order_by(HF.id.desc()).all()
    diag = PatientDiagnostics.query.filter_by(PatientId=pid).order_by(PatientDiagnostics.id.desc()).all()
    if Diagnostics:
        lastDiagDate = Diagnostics.DiagnosticsDate.strftime("%d/%m/%Y")
    else :
        lastDiagDate = "---"
    if request.method == 'POST':
        if  request.form.get("savechf"):
            if chfform.validate_on_submit(): 
                pulse = chfform.Pulse.data
                nyha = chfform.NYHA.data
                killip = chfform.Killip.data
                bnp = chfform.BNP.data
                cystatin = chfform.Cystatin.data
                potassium = chfform.Potassium.data

                
                    
                Xdata = [ [pulse,nyha,killip,bnp,cystatin,potassium ] ]
                arr = os.listdir()
                print(arr)
                with open('hdad/CHF_Detection_Model.pkl', 'rb') as f:
                    clf = pickle.load(f)
                x=clf.predict(Xdata)
                
                if x == 1:
                    result="yes"
                elif x == 0:
                    result="no"
                else:
                    result="error"

                new_record = PatientDiagnostics(PatientId=Patientdata.PatientId, PatientDocId=current_user.DocId, DiagnosticsFor=2)
                db.session.add(new_record)
                db.session.commit()
                DiagnosticsId = PatientDiagnostics.query.filter_by(PatientId=Patientdata.PatientId).order_by(PatientDiagnostics.id.desc()).first()
                if DiagnosticsId:
                    chf = CHF(DiagnosticsId=DiagnosticsId.id,PatientId=pid,PatientDocId=current_user.DocId, Pulse=pulse, NYHA=nyha, Killip=killip,BNP=bnp,Cystatin=cystatin,Potassium=potassium,Result=result)
                    db.session.add(chf)
                    db.session.commit()
                path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
                f = open(path, 'r')
                DiagnosticsCounter = int(f.read())
                f.close()
                f = open(path, 'w')
                f.write(str(DiagnosticsCounter+1))
                f.close()
                return redirect(url_for('showpatient',pid=pid))
            else :
                message="Enter Decimal Numbers Only"
                return render_template('patientdetails.html',name=current_user.DocName,completeform=completeform,data=Patientdata,diagdata=diag,dd=lastDiagDate,chfform=chfform, hfform=hfform,form=2, message=message,message2="",alert=alert,chf=chf,hf=hf,featureform=featureform,delete=delete)
            
            
        elif request.form.get("submitchf"):
            if chfform.validate_on_submit():
                pulse = chfform.Pulse.data
                nyha = chfform.NYHA.data
                killip = chfform.Killip.data
                bnp = chfform.BNP.data
                cystatin = chfform.Cystatin.data
                potassium = chfform.Potassium.data

                pulse = int(pulse)
                nyha = int(nyha)
                killip = int(killip)
                bnp = int(bnp)
                cystatin = int(cystatin)
                potassium = int(potassium)
                Xdata = [ [pulse,nyha,killip,bnp,cystatin,potassium ] ]
                with open('hdad/CHF_Detection_Model.pkl', 'rb') as f:
                    clf = pickle.load(f)
                x=clf.predict(Xdata)

                if x == 1:
                    message="Patient Have Congestive Heart Failure"
                elif x == 0:
                    message="Patient Does Not Have Congestive Heart Failure"
                else:
                    message="error"
                path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
                f = open(path, 'r')
                DiagnosticsCounter = int(f.read())
                f.close()
                f = open(path, 'w')
                f.write(str(DiagnosticsCounter+1))
                f.close()
                return render_template('patientdetails.html',name=current_user.DocName,completeform=completeform,data=Patientdata,diagdata=diag,dd=lastDiagDate,chfform=chfform, hfform=hfform,form=2, message=message,message2="",alert=alert,chf=chf,hf=hf,featureform=featureform,delete=delete)
            else :
                message="Enter Decimal Numbers Only"
                return render_template('patientdetails.html',name=current_user.DocName,completeform=completeform,data=Patientdata,diagdata=diag,dd=lastDiagDate,chfform=chfform, hfform=hfform,form=2, message=message,message2="",alert=alert,chf=chf,hf=hf,featureform=featureform,delete=delete)
            
        elif alert.validate_on_submit() and  request.form.get("alert"):
            email = alert.email.data
            message = alert.message.data
            msg = Message( 
                'Alert', 
                sender ='ashishmishrajune2000@gmail.com', 
                recipients = [email] 
               ) 
            msg.body = message
            mail.send(msg)
            return redirect(url_for('showpatient',pid=pid))
        elif hfform.validate_on_submit() and  request.form.get("save"):
            pulse = hfform.Pulse2.data
            systolicbp = hfform.SystolicBP.data
            lvedd = hfform.LVEDD.data
            bnp = hfform.BNP2.data
            creatnine=hfform.CreatnineKinase.data
            cholestrol = hfform.Cholestrol.data
            cem = hfform.CEM.data
            potassium = hfform.Potassium2.data

            # pulse = int(pulse)      
            # systolicbp = int(systolicbp)
            # lvedd = int(lvedd)
            # bnp = int(bnp)
            # creatnine = int(creatnine)
            # cholestrol = int(cholestrol)
            # cem = int(cem)
            # potassium = int(potassium)
            Xdata = [ [pulse,systolicbp,lvedd,bnp,creatnine,cholestrol,cem,potassium ] ]
            with open('hdad/HF_Classification_Model.pkl', 'rb') as f:
                clf = pickle.load(f)
            x=clf.predict(Xdata)
            
            if x == 1:
               result="HFpEF"
            elif x == 0:
                result="HFrEF"
            else:
                result="error"

            new_record = PatientDiagnostics(PatientId=Patientdata.PatientId, PatientDocId=current_user.DocId, DiagnosticsFor=3)
            db.session.add(new_record)
            db.session.commit()
            DiagnosticsId = PatientDiagnostics.query.filter_by(PatientId=Patientdata.PatientId).order_by(PatientDiagnostics.id.desc()).first()
            if DiagnosticsId:
                hf = HF(DiagnosticsId=DiagnosticsId.id,PatientId=pid,PatientDocId=current_user.DocId, Pulse=pulse, SystolicBP=systolicbp,LVEDD=lvedd,BNP=bnp,CreatnineKinase=creatnine,Cholestrol=cholestrol,CEM=cem,Potassium=potassium,Result=result)
                db.session.add(hf)
                db.session.commit()
            path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
            f = open(path, 'r')
            DiagnosticsCounter = int(f.read())
            f.close()
            f = open(path, 'w')
            f.write(str(DiagnosticsCounter+1))
            f.close()
            return redirect(url_for('showpatient',pid=pid))
        elif hfform.validate_on_submit() and  request.form.get("submithf"):
            pulse = hfform.Pulse2.data
            systolicbp = hfform.SystolicBP.data
            lvedd = hfform.LVEDD.data
            bnp = hfform.BNP2.data
            creatnine=hfform.CreatnineKinase.data
            cholestrol = hfform.Cholestrol.data
            cem = hfform.CEM.data
            potassium = hfform.Potassium2.data

            pulse = int(pulse)      
            systolicbp = int(systolicbp)
            lvedd = int(lvedd)
            bnp = int(bnp)
            creatnine = int(creatnine)
            cholestrol = int(cholestrol)
            cem = int(cem)
            potassium = int(potassium)
            Xdata = [ [pulse,systolicbp,lvedd,bnp,creatnine,cholestrol,cem,potassium ] ]
            with open('hdad/HF_Classification_Model.pkl', 'rb') as f:
                clf = pickle.load(f)
            x=clf.predict(Xdata)
            
            if x == 1:
               message2="Patient Have HFpEF"
            elif x == 0:
                message2="Patient Have HFrEF"
            else:
                message2="error"
            path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
            f = open(path, 'r')
            DiagnosticsCounter = int(f.read())
            f.close()
            f = open(path, 'w')
            f.write(str(DiagnosticsCounter+1))
            f.close()
            return render_template('patientdetails.html',name=current_user.DocName,completeform=completeform,data=Patientdata,diagdata=diag,dd=lastDiagDate,chfform=chfform, hfform=hfform,form=3, message="",message2=message2,alert=alert,hf=hf,chf=chf,featureform=featureform,delete=delete)
        
        elif request.form.get("deletepatient"):
            if delete.validate_on_submit():
                if delete.Input.data == 'Delete':
                    
                    delete_q = Patient.__table__.delete().where(Patient.PatientId == pid)
                    db.session.execute(delete_q)
                    db.session.commit()
                    delete_q = PatientDiagnostics.__table__.delete().where(PatientDiagnostics.PatientId == pid)
                    db.session.execute(delete_q)
                    db.session.commit()
                    delete_q = CHF.__table__.delete().where(CHF.PatientId == pid)
                    db.session.execute(delete_q)
                    db.session.commit()
                    delete_q = HF.__table__.delete().where(HF.PatientId == pid)
                    db.session.execute(delete_q)
                    db.session.commit()
                    return redirect(url_for('dashboard'))
                else :
                    return redirect(url_for('showpatient',pid=pid))
            else :
                return redirect(url_for('showpatient',pid=pid))

        elif request.form.get("download") :
            try:
                return send_from_directory('static',filename='templateDiagnostics.csv', as_attachment=True)
            except FileNotFoundError:
                abort(404)
        elif request.form.get("csvu"):
            print("+")
            print("+")
            print("+")
            print("+")
            print()
            csv_file = request.files['file']
            df = pd.read_csv(csv_file,encoding='latin1')
            df2 = df.copy()
            df.dropna()
            for x, y  in df.iterrows():
            
                if y['Pulse'] and y['NYHA-Cardiac-Function-Classification'] and y['Killip-Grade'] and y['Brain Natriuretic Peptide '] and y['Cystatin '] and y['Potassium ']:
                    pulse = y['Pulse']
                    nyha = y['NYHA-Cardiac-Function-Classification']
                    killip = y['Killip-Grade']
                    bnp = y['Brain Natriuretic Peptide ']
                    cystatin =  y['Cystatin ']
                    potassium = y['Potassium ']

                    
                        
                    Xdata = [ [pulse,nyha,killip,bnp,cystatin,potassium ] ]
                    with open('hdad/CHF_Detection_Model.pkl', 'rb') as f:
                        clf = pickle.load(f)
                    x=clf.predict(Xdata)
                    
                    if x == 1:
                        result="yes"
                    elif x == 0:
                        result="no"
                    else:
                        result="error"

                    new_record = PatientDiagnostics(PatientId=Patientdata.PatientId, PatientDocId=current_user.DocId, DiagnosticsFor=2)
                    db.session.add(new_record)
                    db.session.commit()
                    DiagnosticsId = PatientDiagnostics.query.filter_by(PatientId=Patientdata.PatientId).order_by(PatientDiagnostics.id.desc()).first()
                    if DiagnosticsId:
                        chf = CHF(DiagnosticsId=DiagnosticsId.id,PatientId=pid,PatientDocId=current_user.DocId, Pulse=pulse, NYHA=nyha, Killip=killip,BNP=bnp,Cystatin=cystatin,Potassium=potassium,Result=result)
                        db.session.add(chf)
                        db.session.commit()
                    path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
                    f = open(path, 'r')
                    DiagnosticsCounter = int(f.read())
                    f.close()
                    f = open(path, 'w')
                    f.write(str(DiagnosticsCounter+1))
                    f.close()

                if y['Pulse'] and y['SystolicBP'] and y['left-ventricular-end-diastolic-diameter-LV'] and y['Brain Natriuretic Peptide '] and y['Creatnine Enzymetic Method '] and y['Potassium '] and y['Cholesterol'] and y['Creatnine Kinase ']:
                    pulse = y['Pulse']
                    systolicbp = y['SystolicBP']
                    lvedd = y['left-ventricular-end-diastolic-diameter-LV']
                    bnp =  y['Brain Natriuretic Peptide ']
                    creatnine=y['Creatnine Kinase ']
                    cholestrol = y['Cholesterol']
                    cem = y['Creatnine Enzymetic Method ']
                    potassium = y['Potassium ']

                    pulse = int(pulse)      
                    systolicbp = int(systolicbp)
                    lvedd = int(lvedd)
                    bnp = int(bnp)
                    creatnine = int(creatnine)
                    cholestrol = int(cholestrol)
                    cem = int(cem)
                    potassium = int(potassium)
                    Xdata = [ [pulse,systolicbp,lvedd,bnp,creatnine,cholestrol,cem,potassium ] ]
                    with open('hdad/HF_Classification_Model.pkl', 'rb') as f:
                        clf = pickle.load(f)
                    x=clf.predict(Xdata)
                    
                    if x == 1:
                        result="HFpEF"
                    elif x == 0:
                        result="HFrEF"
                    else:
                        result="error"

                    new_record = PatientDiagnostics(PatientId=Patientdata.PatientId, PatientDocId=current_user.DocId, DiagnosticsFor=3)
                    db.session.add(new_record)
                    db.session.commit()
                    DiagnosticsId = PatientDiagnostics.query.filter_by(PatientId=Patientdata.PatientId).order_by(PatientDiagnostics.id.desc()).first()
                    if DiagnosticsId:
                        hf = HF(DiagnosticsId=DiagnosticsId.id,PatientId=pid,PatientDocId=current_user.DocId, Pulse=pulse, SystolicBP=systolicbp,LVEDD=lvedd,BNP=bnp,CreatnineKinase=creatnine,Cholestrol=cholestrol,CEM=cem,Potassium=potassium,Result=result)
                        db.session.add(hf)
                        db.session.commit()
                    path = os.getcwd()+'/hdad/Diagnostics-Counter.txt'
                    f = open(path, 'r')
                    DiagnosticsCounter = int(f.read())
                    f.close()
                    f = open(path, 'w')
                    f.write(str(DiagnosticsCounter+1))
                    f.close()
                    

            print("+")
            print("+")
            print("+")
            return redirect(url_for('showpatient',pid=pid))

        elif featureform.validate_on_submit and request.form.get("featureform"):
            common_feature = ["Pulse","BNP","Potassium"]
            chf_feature = ["NYHA","Killip","Cystatin"]
            hf_feature = ["SystolicBP","LVEDD","CreatnineKinase","Cholestrol","CEM"]
            if featureform.Feature2.data=='Date':
                features=[]
                dates=[]
                try:
                    if featureform.Feature1.data == 'BNP' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.BNP))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.BNP))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                    if featureform.Feature1.data == 'Pulse' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.Pulse))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.Pulse))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                    if featureform.Feature1.data == 'NYHA' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.NYHA))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                       
                    if featureform.Feature1.data == 'Killip' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.Killip))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                        
                    if featureform.Feature1.data == 'Cystatin' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.Cystatin))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                        
                    if featureform.Feature1.data == 'Potassium' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.Potassium))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.Potassium))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                    if featureform.Feature1.data == 'SystolicBP' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.SystolicBP))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                    if featureform.Feature1.data == 'LVEDD' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.LVEDD))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                    if featureform.Feature1.data == 'Cholestrol' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.Cholestrol))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                    if featureform.Feature1.data == 'CEM' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features = np.append(features,float(row.CEM))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                    if featureform.Feature1.data == 'CreatnineKinase' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature :
                            features = np.append(features,float(row.CreatnineKinase))
                            dates = np.append(dates,str(row.DiagnosticsDate))
                            print(features,dates)
                        
                        
                except:
                   raise("error at line 871")
                
                # feature_data = feature_data_hf+feature_data_chf
                    
                fname = featureform.Feature1.data
                feature_data=features
                print(feature_data)
                # feature_data=feature_data.flatten()
                # fdata = feature_data[:,0]
                # date = feature_data[:,1]
                
                image = create_graphs(pid,fname,features,dates)
                print("\n")
            else :
                
                features1=[]
                features2=[]
                try:
                    if featureform.Feature1.data == 'BNP' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.BNP))
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.BNP))
                    
                    if featureform.Feature1.data == 'Pulse' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.Pulse))
                            
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.Pulse))
                            
                    if featureform.Feature1.data == 'NYHA' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.NYHA))
                            
                       
                    if featureform.Feature1.data == 'Killip' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.Killip))
                            
                        
                    if featureform.Feature1.data == 'Cystatin' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.Cystatin))
                            
                        
                    if featureform.Feature1.data == 'Potassium' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.Potassium))
                            
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.Potassium))
                            
                    if featureform.Feature1.data == 'SystolicBP' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.SystolicBP))
                            
                    if featureform.Feature1.data == 'LVEDD' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.LVEDD))
                            
                    if featureform.Feature1.data == 'Cholestrol' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.Cholestrol))
                            
                    if featureform.Feature1.data == 'CEM' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features1 = np.append(features1,float(row.CEM))
                            
                    if featureform.Feature1.data == 'CreatnineKinase' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature :
                            features1 = np.append(features1,float(row.CreatnineKinase))
                            
                        
                        
                except:
                   raise("error")
                try:
                    if featureform.Feature2.data == 'BNP' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.BNP))
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.BNP))
                    
                    if featureform.Feature2.data == 'Pulse' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.Pulse))
                            
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.Pulse))
                            
                    if featureform.Feature2.data == 'NYHA' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.NYHA))
                            
                       
                    if featureform.Feature2.data == 'Killip' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.Killip))
                            
                        
                    if featureform.Feature2.data == 'Cystatin' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.Cystatin))
                            
                        
                    if featureform.Feature2.data == 'Potassium' :
                        feature = CHF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.Potassium))
                            
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.Potassium))
                            
                    if featureform.Feature2.data == 'SystolicBP' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.SystolicBP))
                            
                    if featureform.Feature2.data == 'LVEDD' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.LVEDD))
                            
                    if featureform.Feature2.data == 'Cholestrol' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.Cholestrol))
                            
                    if featureform.Feature2.data == 'CEM' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature:
                            features2 = np.append(features2,float(row.CEM))
                            
                    if featureform.Feature2.data == 'CreatnineKinase' :
                        feature = HF.query.filter_by(PatientId=pid).all()
                        for row in feature :
                            features2 = np.append(features2,float(row.CreatnineKinase))
                            
                          
                        
                        
                except:
                    raise("error")
                if features1.shape[0]>features2.shape[0]:
                    features1 = features1[0:features2.shape[0]]
                elif features1.shape[0]<features2.shape[0]:
                    features2 = features2[0:features1.shape[0]]

                print(pid)
                print("------------")
                image = create_graphs(pid,featureform.Feature1.data,features1,features2,False,featureform.Feature2.data)
                print("\n")
            
            return render_template('patientdetails.html',name=current_user.DocName,completeform=completeform,data=Patientdata,diagdata=diag,dd=lastDiagDate,chfform=chfform, hfform=hfform, form=4, message="",message2="",alert=alert,chf=chf,hf=hf,image=image,featureform=featureform,delete=delete)
    return render_template('patientdetails.html',name=current_user.DocName,completeform=completeform,data=Patientdata,diagdata=diag,dd=lastDiagDate,chfform=chfform, hfform=hfform, form=0, message="",message2="",alert=alert,chf=chf,hf=hf,featureform=featureform,delete=delete)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))
